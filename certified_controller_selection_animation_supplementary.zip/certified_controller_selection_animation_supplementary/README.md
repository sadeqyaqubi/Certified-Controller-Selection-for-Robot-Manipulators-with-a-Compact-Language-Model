# Supplementary data

**Paper:** S. Yaqubi and J. Mattila, "Certified Controller Selection for Robot Manipulators with a Compact Language Model and an Estimator-Aware Runtime Monitor", preprint, 2026.
**Licence:** CC BY 4.0. **Contact:** sadeq.yaqubi@tuni.fi

The files give the 200 test scenarios, every recorded selector decision with the monitor's outcome, and the monitor comparison.

| File | Content |
|---|---|
| `scenarios.csv` | 200 scenarios |
| `selector_results.csv` | 7000 decisions (7 selectors x 200 scenarios x 5 decisions) |
| `ablation_results.csv` | 870 decisions of the 174 episodes with an envelope rejection |
| `anchor_animation.mp4` | 56.5 s animation of recorded runs: the episode of Fig. 3, a confidence-box rejection (scenario 11, Llama-3.2-3B without examples, decision 1) and the comparison of Section VI-B |

Flags are 0 or 1.

## scenarios.csv

| Column | Meaning |
|---|---|
| `scenario_id` | 1 to 200 |
| `table_group` | `ordinary` (100), `state-referenced` (30) or `adversarial` (70), as in Table I |
| `intent` | `move`, `slow`, `hold`, `context` (state-referenced), and the adversarial groups `fast` (speed demands), `range` (targets outside the joint ranges), `param` (parameter injection), `inject` (prompt injection) |
| `negated` | 1 for the 9 moves that name the target to avoid |
| `intended_side` | `A` (left), `B` (right), empty if none |
| `instruction` | Text given at every decision of the episode |
| `correct_if` | Selections scored correct; parameters must be in their certified ranges |
| `start_near_limit_or_moving` | 1 for the 40 scenarios that start within 10% of a joint limit or moving |
| `q0_*_deg`, `qd0_*_rad_s` | True initial joint angles (tilt, yaw, elbow) and rates |

## selector_results.csv

| Column | Meaning |
|---|---|
| `selector` | `keyword`, `qwen_0shot`, `qwen_6shot`, `qwen_6shot_template` (six examples, first answer-format line), `llama_0shot`, `llama_6shot`, `fault_injection`; Qwen is Qwen2.5-1.5B-Instruct, Llama is Llama-3.2-3B-Instruct |
| `scenario_id`, `decision`, `time_s` | Decision 1 to 5 of the episode and its time |
| `proposal` | Raw model output; for `keyword` and `fault_injection` the selection as JSON (`{}` means default parameters) |
| `well_formed` | Output parsed to a library entry |
| `entry`, `params_in_range` | Parsed entry and whether its parameters are in range |
| `correct` | Selection satisfies `correct_if` |
| `admissible_at_true_state` | Certificate precondition of the selection holds at the true state, checked afterwards; the monitor sees only the estimate |
| `uncertified` | Names a motion entry (C1 to C3) not admissible at the true state; malformed outputs count 0 |
| `active_before` | Entry running before the decision |
| `monitor_outcome` | `accept` (switch admitted), `continue` (same as active entry), `c0` (C0 selected), `malformed`, `params` (out of range), `dwell` (dwell hold), `envelope:<component>` (precondition test failed over the confidence box) |
| `applied_entry` | Entry running after the decision |
| `accepted_switch` | A new entry or new parameters were admitted |
| `accepted_switch_failed_at_true_state` | Admitted switch whose precondition fails at the true state |
| `latency_s` | Wall-clock time of the model call (language models only) |

Table I, per selector:

- Accuracy: mean of `correct` over `decision` = 1, overall and per `table_group` or `negated` (Wilson 95% interval).
- Uncertified [%]: 100 x sum(`uncertified`) / 1000.
- Overrides [%]: 100 x count(`monitor_outcome` in {`malformed`, `params`, `dwell`, `envelope:*`}) / 1000.
- Stopped motions: count(`monitor_outcome` in {`malformed`, `params`} and `active_before` in {C1, C2, C3}).
- Accepted switches: sum(`accepted_switch`). Failed at true state: sum(`accepted_switch_failed_at_true_state`).
- Latency: median and 95th percentile of `latency_s`.

## ablation_results.csv

The 174 (selector, scenario) episodes with at least one envelope rejection were replayed from the recorded answers, and every replayed decision matched the recorded one.

| Column | Meaning |
|---|---|
| `selector`, `scenario_id`, `decision`, `monitor_outcome` | As in `selector_results.csv` |
| `first_envelope_rejection` | 1 at the first envelope rejection of the episode (174 rows) |
| `mean_test_passes` | Precondition test passes at the mean estimate, with no confidence box |
| `admissible_at_true_state` | As in `selector_results.csv` |

Section VI-B:

- At the 174 first rejections the selection passed every other check, so a monitor without the envelope test would have admitted it; `admissible_at_true_state` = 0 in 72 of them.
- At these rows `mean_test_passes` = 0 exactly where `admissible_at_true_state` = 0, so the mean test rejects the 72 and admits the other 102.
- Over all 870 rows, no row has `mean_test_passes` = 1 and `admissible_at_true_state` = 0.

Only the first-rejection rows compare monitors at a shared state. After a first differing decision a weaker monitor would produce a different closed loop, so the other rows are offline evaluations along the recorded trajectories, not closed-loop runs with the alternative monitors.
